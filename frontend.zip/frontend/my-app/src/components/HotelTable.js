import React from 'react';
import { DataGrid } from '@mui/x-data-grid';
import { Box, Container } from '@mui/material';

const HotelTable = ({ data }) => {
    const columns = [
        { field: 'id', headerName: 'ID', width: 90 },
        { field: 'hotel_name', headerName: 'Hotel Name', width: 150 },
        { field: 'address', headerName: 'Address', width: 200 },
        { field: 'city', headerName: 'City', width: 150 },
        { field: 'checkin_time', headerName: 'Check-in Time', width: 200 },
        { field: 'checkout_time', headerName: 'Check-out Time', width: 200 },
        { field: 'booking_date', headerName: 'Booking Date', width: 200 },
        { field: 'available_rooms', headerName: 'Available Rooms', width: 150 },
        { field: 'price', headerName: 'Price', width: 100 }
    ];

    const rows = data.map((item, index) => ({
        id: index + 1,
        hotel_name: item.hotel_name,
        address: item.address,
        city: item.city,
        checkin_time: item.checkin_time,
        checkout_time: item.checkout_time,
        booking_date: item.booking_date,
        available_rooms: item.available_rooms,
        price: item.price
    }));

    return (
        <Container>
            <Box sx={{ height: 400, width: '100%' }}>
                <DataGrid
                    rows={rows}
                    columns={columns}
                    pageSize={5}
                    rowsPerPageOptions={[5]}
                    checkboxSelection
                />
            </Box>
        </Container>
    );
};

export default HotelTable;
