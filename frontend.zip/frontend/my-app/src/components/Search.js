import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';
import './Search.css';
import FlightTable from './FlightTable';
import HotelTable from './HotelTable';
import CarTable from './CarTable'; 
import { Button } from '@mui/material';

const Search = () => {
    const [activeTab, setActiveTab] = useState('flight');
    const navigate = useNavigate();
    const [formData, setFormData] = useState({
        departure_city: '',
        arrival_city: '',
        city: '',
        checkin_time: '',
        checkout_time: '',
        pick_up_location: '',
        where_to_go: ''
    });
    const [results, setResults] = useState([]);

    const handleTabClick = (tab) => {
        setActiveTab(tab);
        setFormData({
            departure_city: '',
            arrival_city: '',
            city: '',
            checkin_time: '',
            checkout_time: '',
            pick_up_location: '',
            where_to_go: ''
        });
        setResults([]);
    };

    const handleChange = (e) => {
        setFormData({ ...formData, [e.target.name]: e.target.value });
    };

    useEffect(() => {
        console.log(results);
    }, [results]);

    const handleSubmit = async (e) => {
        e.preventDefault();
        let url = '';
        let params = {};

        switch (activeTab) {
            case 'flight':
                url = 'http://127.0.0.1:5001/search/flight_rentals';
                params = { departure_city: formData.departure_city, arrival_city: formData.arrival_city };
                break;
            case 'hotel':
                url = 'http://127.0.0.1:5001/search/hotels';
                params = {
                    city: formData.city,
                    checkin_time: formatDate(formData.checkin_time),
                    checkout_time: formatDate(formData.checkout_time)
                };
                break;
            case 'car':
                url = 'http://127.0.0.1:5001/search/car_rentals';
                params = { pick_up_location: formData.pick_up_location, where_to_go: formData.where_to_go };
                break;
            default:
                return;
        }

        try {
            const response = await axios.get(url, {
                headers: {
                    'Content-Type': 'application/json',
                    Authorization: 'Bearer YOUR_ACCESS_TOKEN'
                },
                params
            });
            setResults(response.data);
        } catch (error) {
            console.error('Error fetching data:', error);
            setResults([]);
        }
    };

    const formatDate = (dateString) => {
        const date = new Date(dateString);
        return date.toISOString().slice(0, 10);
    };

    return (
        <div className="search-page">
            <Button style={{position: 'absolute', top: '10px', right: '20px', padding: '10px', backgroundColor: 'Red', color: 'white', fontWeight: 'bold' }} 
            onClick={() => {
                navigate('/');
                alert('Are you sure to exit?')
            }}
                >Logout</Button>
            <div className="tabs">
                <button onClick={() => handleTabClick('flight')} className={activeTab === 'flight' ? 'active' : ''}>Search Flight</button>
                <button onClick={() => handleTabClick('hotel')} className={activeTab === 'hotel' ? 'active' : ''}>Search Hotel</button>
                <button onClick={() => handleTabClick('car')} className={activeTab === 'car' ? 'active' : ''}>Search Cab</button>
            </div>

            <form onSubmit={handleSubmit} className="search-form">
                {activeTab === 'flight' && (
                    <div>
                        <h2>Search Flights</h2>
                        <input type="text" name="departure_city" placeholder="Departure City" onChange={handleChange} required />
                        <input type="text" name="arrival_city" placeholder="Arrival City" onChange={handleChange} required />
                    </div>
                )}
                {activeTab === 'hotel' && (
                    <div>
                        <h2>Search Hotels</h2>
                        <input type="text" name="city" placeholder="City" onChange={handleChange} required />
                        <input type="date" name="checkin_time" onChange={handleChange} required />
                        <input type="date" name="checkout_time" onChange={handleChange} required />
                    </div>
                )}
                {activeTab === 'car' && (
                    <div>
                        <h2>Search Cars</h2>
                        <input type="text" name="pick_up_location" placeholder="Pick Up Location" onChange={handleChange} required />
                        <input type="text" name="where_to_go" placeholder="Destination" onChange={handleChange} required />
                    </div>
                )}
                <button type="submit">Search</button>
            </form>

            <div className="results">
                {results.length > 0 ? (
                    activeTab === 'flight' ? (
                        <FlightTable data={results} />
                    ) : activeTab === 'hotel' ? (
                        <HotelTable data={results} />
                    ) : (
                        <CarTable data={results} /> 
                    )
                ) : (
                    <div>No results found.</div>
                )}
            </div>
        </div>
    );
};

export default Search;