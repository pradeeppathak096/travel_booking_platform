import React from 'react';
import { DataGrid } from '@mui/x-data-grid';
import { Box, Container } from '@mui/material';

const FlightTable = ({ data }) => {
    const columns = [
        { field: 'id', headerName: 'ID', width: 90 },
        { field: 'airline', headerName: 'Airline', width: 150 },
        { field: 'arrival_city', headerName: 'Arrival City', width: 150 },
        { field: 'arrival_time', headerName: 'Arrival Time', width: 200 },
        { field: 'departure_city', headerName: 'Departure City', width: 150 },
        { field: 'departure_time', headerName: 'Departure Time', width: 200 },
        { field: 'flight_id', headerName: 'Flight ID', width: 150 },
        { field: 'flight_number', headerName: 'Flight Number', width: 150 },
        { field: 'price', headerName: 'Price', width: 100 }
    ];

    const rows = data.map((item, index) => ({
        id: index + 1,
        airline: item.airline,
        arrival_city: item.arrival_city,
        arrival_time: item.arrival_time,
        departure_city: item.departure_city,
        departure_time: item.departure_time,
        flight_id: item.flight_id,
        flight_number: item.flight_number,
        price: item.price
    }));

    return (
        <Container>
            <Box sx={{ height: 400, width: '100%' }}>
                <DataGrid
                    rows={rows}
                    columns={columns}
                    pageSize={5}
                    rowsPerPageOptions={[5]}
                    checkboxSelection
                />
            </Box>
        </Container>
    );
};

export default FlightTable;
