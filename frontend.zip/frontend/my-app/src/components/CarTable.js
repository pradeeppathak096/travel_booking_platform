import React from 'react';
import './Table.css';

const CarTable = ({ data }) => {
    return (
        <div className="table-container">
            <table>
                <thead>
                    <tr>
                        <th>Car Model</th>
                        <th>City</th>
                        <th>Pick Up Location</th>
                        <th>Rental Company</th>
                        <th>Rental Price</th>
                        <th>Destination</th>
                    </tr>
                </thead>
                <tbody>
                    {data.map((car, index) => (
                        <tr key={index}>
                            <td>{car.car_model}</td>
                            <td>{car.city}</td>
                            <td>{car.pick_up_location}</td>
                            <td>{car.rental_company}</td>
                            <td>{car.rental_price}</td>
                            <td>{car.where_to_go}</td>
                        </tr>
                    ))}
                </tbody>
            </table>
        </div>
    );
};

export default CarTable;

