// import React, { createContext, useState, useContext } from 'react';

// const SearchContext = createContext();

// export const SearchProvider = ({ children }) => {
//   const [destination, setDestination] = useState('');
//   const [checkIn, setCheckIn] = useState(null);
//   const [checkOut, setCheckOut] = useState(null);
//   const [adultCount, setAdultCount] = useState(1);
//   const [childCount, setChildCount] = useState(0);

//   const saveSearchValues = (dest, checkInDate, checkOutDate, adults, children) => {
//     setDestination(dest);
//     setCheckIn(checkInDate);
//     setCheckOut(checkOutDate);
//     setAdultCount(adults);
//     setChildCount(children);
//   };

//   return (
//     <SearchContext.Provider value={{ destination, checkIn, checkOut, adultCount, childCount, saveSearchValues }}>
//       {children}
//     </SearchContext.Provider>
//   );
// };

// export const useSearchContext = () => useContext(SearchContext);
