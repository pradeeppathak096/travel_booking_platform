# import logging
# from flask import Flask, request, jsonify, redirect, url_for
# from flask_login import LoginManager, login_required, current_user, UserMixin, login_user, logout_user
# import os
# import psycopg2
# from psycopg2.extras import RealDictCursor
# import urllib.parse as urlparse
# from passlib.hash import pbkdf2_sha256
# from datetime import datetime, timedelta
# import uuid
# import jwt
# from flask_cors import CORS
# import requests

# from authlib.integrations.flask_client import OAuth
# from dotenv import load_dotenv

# load_dotenv()

# SECRET_KEY = os.getenv('SECRET_KEY', '1234')

# app = Flask(__name__)
# CORS(app)
# app.config['SECRET_KEY'] = SECRET_KEY

# oauth = OAuth(app)

# login_manager = LoginManager()
# login_manager.init_app(app)

# database_url = os.getenv('DATABASE_URL', 'postgresql://postgres:pradeeppinaca@localhost:5432/booking')
# url = urlparse.urlparse(database_url)
# dbname = url.path[1:]
# user = url.username
# password = url.password
# host = url.hostname
# port = url.port

# def get_db_connection():
#     conn = psycopg2.connect(
#         dbname=dbname,
#         user=user,
#         password=password,
#         host=host,
#         port=port
#     )
#     return conn

# def init_db():
#     conn = get_db_connection()
#     cur = conn.cursor()

#     cur.execute('''
#         CREATE TABLE IF NOT EXISTS users (
#             id SERIAL PRIMARY KEY,
#             full_name VARCHAR(100),
#             email VARCHAR(100) UNIQUE,
#             phone VARCHAR(20),
#             password VARCHAR(200),
#             dob DATE,
#             address TEXT,
#             country VARCHAR(100),
#             gender VARCHAR(10),
#             role VARCHAR(10) DEFAULT 'traveler'
#         )
#     ''')

#     cur.execute('''
#         CREATE TABLE IF NOT EXISTS flight_table (
#             flight_id VARCHAR(100) PRIMARY KEY,
#             airline VARCHAR(100),
#             flight_number VARCHAR(10),
#             departure_city VARCHAR(100),
#             arrival_city VARCHAR(100),
#             departure_time TIMESTAMP,
#             arrival_time TIMESTAMP,
#             price DECIMAL(10, 2)
#         )
#     ''')

#     cur.execute('''
#         CREATE TABLE IF NOT EXISTS cab (
#             id SERIAL PRIMARY KEY,
#             rental_company VARCHAR(100),
#             city VARCHAR(100),
#             pick_up_location VARCHAR(100),
#             where_to_go VARCHAR(100),
#             car_model VARCHAR(100),
#             available_cars INTEGER,
#             rental_price DECIMAL(10, 2)
#         )
#     ''')

#     cur.execute('''
#         CREATE TABLE IF NOT EXISTS flight_booking (
#             id SERIAL PRIMARY KEY,
#             full_name VARCHAR(100) NOT NULL,
#             user_id VARCHAR(50) NOT NULL,
#             departure_city VARCHAR(100) NOT NULL,
#             arrival_city VARCHAR(100) NOT NULL,
#             seat_number VARCHAR(10) NOT NULL,
#             flight_time TIMESTAMP NOT NULL,
#             airline VARCHAR(100) NOT NULL,
#             flight_id VARCHAR(50) NOT NULL,
#             booking_date DATE NOT NULL,
#             num_adults INTEGER NOT NULL,
#             num_children INTEGER NOT NULL,
#             total_travelers INTEGER NOT NULL
#         )
#     ''')

#     cur.execute('''
#         CREATE TABLE IF NOT EXISTS hotel_booking (
#             id SERIAL PRIMARY KEY,
#             full_name VARCHAR(100) NOT NULL,
#             email VARCHAR(100) NOT NULL,
#             hotel_name VARCHAR(100) NOT NULL,
#             city VARCHAR(50) NOT NULL,
#             address VARCHAR(100) NOT NULL,
#             num_rooms INTEGER NOT NULL,
#             num_guests INTEGER NOT NULL,
#             booking_date TIMESTAMP DEFAULT NOW(),
#             checkin_time TIMESTAMP,
#             checkout_time TIMESTAMP,
#             price DECIMAL(10, 2)
#         )
#     ''')

#     cur.execute('''
#         CREATE TABLE IF NOT EXISTS role_table (
#             role_id SERIAL PRIMARY KEY,
#             role_name VARCHAR(100) NOT NULL,
#             created_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP
#         )
#     ''')

#     cur.execute('''
#         CREATE TABLE IF NOT EXISTS reviews (
#             id SERIAL PRIMARY KEY,
#             user_id VARCHAR(50) NOT NULL,
#             service_type VARCHAR(50) NOT NULL,
#             service_id VARCHAR(100) NOT NULL,
#             rating INTEGER NOT NULL,
#             review TEXT,
#             created_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP
#         )
#     ''')

#     conn.commit()
#     cur.close()
#     conn.close()

# class User(UserMixin):
#     def __init__(self, id):
#         self.id = id

# @login_manager.user_loader
# def load_user(user_id):
#     return User(user_id)

# def authorize_request(request):
#     auth_header = request.headers.get('Authorization')
#     if auth_header and auth_header.startswith('Bearer '):
#         token = auth_header.split()[1]
#     else:
#         return jsonify({"error": "Authorization header missing or malformed"}), 401

#     try:
#         payload = jwt.decode(token, SECRET_KEY, algorithms=['HS256'])
#     except jwt.ExpiredSignatureError:
#         return jsonify({"error": "Token has expired"}), 401
#     except jwt.InvalidTokenError:
#         return jsonify({"error": "Invalid token"}), 401

#     return None, payload

# @app.route("/register", methods=["POST"])
# def register():
#     data = request.get_json()

#     full_name = data.get("full_name")
#     email = data.get("email")
#     password = data.get("password")
#     phone = data.get("phone")
#     dob = data.get("dob")
#     address = data.get("address")
#     country = data.get("country")
#     gender = data.get("gender")

#     if not all([full_name, email, password, phone, dob, address, country, gender]):
#         return jsonify({"message": "All fields are required"}), 400

#     conn = get_db_connection()
#     cur = conn.cursor(cursor_factory=RealDictCursor)

#     cur.execute("""SELECT "email" FROM "users" WHERE "email" = %s""", (email,))
#     existing_user = cur.fetchone()

#     if existing_user:
#         cur.close()
#         conn.close()
#         return jsonify({"message": "Email already exists"}), 400

#     hashed_password = pbkdf2_sha256.hash(password)
#     cur.execute(
#         """INSERT INTO "users" ("full_name", "email", "phone", "password", "dob", "address", "country", "gender") 
#         VALUES (%s, %s, %s, %s, %s, %s, %s, %s)""",
#         (full_name, email, phone, hashed_password, dob, address, country, gender)

#     )
#     conn.commit()
#     cur.close()
#     conn.close()

#     return jsonify({"message": "User registered successfully"}), 201

# @app.route("/login", methods=["POST"])
# def login():
#     data = request.get_json()

#     email = data.get("email")
#     password = data.get("password")

#     if not email or not password:
#         return jsonify({"message": "Email and password are required"}), 400

#     conn = get_db_connection()
#     cur = conn.cursor(cursor_factory=RealDictCursor)

#     cur.execute("""SELECT "id", "full_name", "country", "password", "gender", "dob" FROM "users" WHERE "email" = %s""", (email,))
#     user = cur.fetchone()

#     if user and pbkdf2_sha256.verify(password, user["password"]):
#         login_user(User(user['id']))
#         payload = {
#             "user_name": user["full_name"],
#             "gender": user["gender"],
#             "country": user["country"],
#             "user_id": user["id"],
#             "exp": datetime.utcnow() + timedelta(days=1)
#         }
#         token = jwt.encode(payload, SECRET_KEY, algorithm="HS256")
#         cur.close()
#         conn.close()
#         return jsonify({"token": token}), 200
#     else:
#         cur.close()
#         conn.close()
#         return jsonify({"message": "Invalid email or password"}), 401

# @app.route("/logout", methods=["POST"])
# def logout():
#     error_response, payload = authorize_request(request)
#     if error_response:
#         return error_response
#     logout_user()
#     return jsonify({"message": "Logout successful"}), 200

# @app.route("/profile")
# @login_required
# def profile():
#     return jsonify({"message": "User profile"}), 200

# @app.route("/add-flights", methods=["POST"])
# @login_required
# def add_flights():
#     data = request.get_json()

#     if not isinstance(data, list):
#         return jsonify({"message": "Invalid input, expected a list of JSON objects"}), 400

#     conn = get_db_connection()
#     cur = conn.cursor()

#     for flight in data:
#         flight_id = flight.get('flight_id')
#         airline = flight.get('airline')
#         flight_number = flight.get('flight_number')
#         departure_city = flight.get('departure_city')
#         arrival_city = flight.get('arrival_city')
#         departure_time = flight.get('departure_time')
#         arrival_time = flight.get('arrival_time')
#         price = flight.get('price')

#         if not all([flight_id, airline, flight_number, departure_city, arrival_city, departure_time, arrival_time, price]):
#             cur.close()
#             conn.close()
#             return jsonify({"message": "All fields are required for each flight"}), 400

#         cur.execute(
#             '''INSERT INTO flight_table (flight_id, airline, flight_number, departure_city, arrival_city, departure_time, arrival_time, price)
#             VALUES (%s, %s, %s, %s, %s, %s, %s, %s)
#             ON CONFLICT (flight_id) DO NOTHING''',
#             (flight_id, airline, flight_number, departure_city, arrival_city, departure_time, arrival_time, price)
#         )
    
#     conn.commit()
#     cur.close()
#     conn.close()
#     return jsonify({"message": "Flights added successfully"}), 201

# @app.route("/search_flights", methods=["GET"])
# @login_required
# def get_flights():
#     error_response, payload = authorize_request(request)
#     if error_response:
#         return error_response

#     conn = get_db_connection()
#     cur = conn.cursor(cursor_factory=RealDictCursor)
#     cur.execute("SELECT * FROM flight_table")
#     flights = cur.fetchall()
#     cur.close()
#     conn.close()
#     return jsonify(flights), 200

# @app.route("/book_flight", methods=["POST"])
# @login_required
# def book_flight():
#     data = request.get_json()
#     error_response, payload = authorize_request(request)
#     if error_response:
#         return error_response

#     full_name = data.get("full_name")
#     user_id = data.get("user_id")
#     departure_city = data.get("departure_city")
#     arrival_city = data.get("arrival_city")
#     seat_number = data.get("seat_number")
#     departure_time = data.get("departure_time")
#     arrival_time = data.get("arrival_time")
#     airline = data.get("airline")
#     flight_id = data.get("flight_id")
#     num_adults = data.get("num_adults")
#     num_children = data.get("num_children")

#     if not all([full_name, user_id, departure_city, arrival_city, seat_number, departure_time, arrival_time, airline, flight_id, num_adults, num_children]):
#         return jsonify({"message": "All fields are required"}), 400

#     try:
#         flight_time = datetime.strptime(flight_time, '%Y-%m-%d %H:%M:%S')
#     except ValueError:
#         return jsonify({"message": "Invalid date format for flight_time, expected 'YYYY-MM-DD HH:MM:SS'"}), 400

#     total_travelers = num_adults + num_children

#     conn = get_db_connection()
#     cur = conn.cursor()
#     cur.execute(
#         '''INSERT INTO flight_booking (full_name, user_id, departure_city, arrival_city, seat_number,departure_time, arrival_time , airline, flight_id, booking_date, num_adults, num_children, total_travelers)
#         VALUES (%s, %s, %s, %s, %s, %s, %s, %s, NOW(), %s, %s, %s)''',
#         (full_name, user_id, departure_city, arrival_city, seat_number, flight_time, departure_time ,arrival_time, airline, flight_id, num_adults, num_children, total_travelers)
#     )
#     conn.commit()
#     cur.close()
#     conn.close()
#     return jsonify({"message": "Flight booked successfully"}), 201

# @app.route("/get_flight_bookings", methods=["GET"])
# @login_required
# def get_flight_bookings():
#     error_response, payload = authorize_request(request)
#     if error_response:
#         return error_response

#     conn = get_db_connection()
#     cur = conn.cursor(cursor_factory=RealDictCursor)
#     cur.execute("SELECT * FROM flight_booking")
#     bookings = cur.fetchall()
#     cur.close()
#     conn.close()
#     return jsonify(bookings), 200

# @app.route('/add_cabs', methods=['POST'])
# @login_required
# def add_cabs():
#     data = request.get_json()
#     error_response, payload = authorize_request(request)
#     if error_response:
#         return error_response

#     if not isinstance(data, list):
#         return jsonify({"message": "Invalid input, expected a list of JSON objects"}), 400

#     conn = get_db_connection()
#     cur = conn.cursor()

#     for cab in data:
#         rental_company = cab.get('rental_company')
#         city = cab.get('city')
#         pick_up_location = cab.get('pick_up_location')
#         where_to_go = cab.get('where_to_go')
#         car_model = cab.get('car_model')
#         available_cars = cab.get('available_cars')
#         rental_price = cab.get('rental_price')

#         if not all([rental_company, city, pick_up_location, where_to_go, car_model, available_cars, rental_price]):
#             cur.close()
#             conn.close()
#             return jsonify({"message": "All fields are required for each cab"}), 400

#         cur.execute(
#             '''INSERT INTO cab (rental_company, city, pick_up_location, where_to_go, car_model, available_cars, rental_price)
#             VALUES (%s, %s, %s, %s, %s, %s, %s)
#             ON CONFLICT DO NOTHING''',
#             (rental_company, city, pick_up_location, where_to_go, car_model, available_cars, rental_price)
#         )

#     conn.commit()
#     cur.close()
#     conn.close()
#     return jsonify({"message": "Cabs added successfully"}), 201

# @app.route("/search-cabs", methods=["GET"])
# @login_required
# def get_cabs():
#     error_response, payload = authorize_request(request)
#     if error_response:
#         return error_response

#     conn = get_db_connection()
#     cur = conn.cursor(cursor_factory=RealDictCursor)
#     cur.execute("SELECT * FROM cab")
#     cabs = cur.fetchall()
#     cur.close()
#     conn.close()
#     return jsonify(cabs), 200

# @app.route('/book-hotel', methods=['POST'])
# @login_required
# def book_hotel():
#     data = request.get_json()
#     error_response, payload = authorize_request(request)
#     if error_response:
#         return error_response

#     full_name = data.get('full_name')
#     email = data.get('email')
#     hotel_name = data.get('hotel_name')
#     city = data.get('city')
#     address = data.get('address')
#     num_rooms = data.get('num_rooms')
#     num_guests = data.get('num_guests')
#     checkin_time = data.get('checkin_time')
#     checkout_time = data.get('checkout_time')
#     price = data.get('price')

#     if not all([full_name, email, hotel_name, city, address, num_rooms, num_guests, checkin_time, checkout_time, price]):
#         return jsonify({"message": "All fields are required"}), 400

#     try:
#         checkin_time = datetime.strptime(checkin_time, '%Y-%m-%d %H:%M:%S')
#         checkout_time = datetime.strptime(checkout_time, '%Y-%m-%d %H:%M:%S')
#     except ValueError:
#         return jsonify({"message": "Invalid date format, expected 'YYYY-MM-DD HH:MM:SS'"}), 400

#     conn = get_db_connection()
#     cur = conn.cursor()
#     cur.execute(
#         '''INSERT INTO hotel_booking (full_name, email, hotel_name, city, address, num_rooms, num_guests, checkin_time, checkout_time, price)
#         VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s)''',
#         (full_name, email, hotel_name, city, address, num_rooms, num_guests, checkin_time, checkout_time, price)
#     )
#     conn.commit()
#     cur.close()
#     conn.close()
#     return jsonify({"message": "Hotel booked successfully"}), 201

# @app.route("/get-hotel-bookings", methods=["GET"])
# @login_required
# def get_hotel_bookings():
#     error_response, payload = authorize_request(request)
#     if error_response:
#         return error_response

#     conn = get_db_connection()
#     cur = conn.cursor(cursor_factory=RealDictCursor)
#     cur.execute("SELECT * FROM hotel_booking")
#     hotel_bookings = cur.fetchall()
#     cur.close()
#     conn.close()
#     return jsonify(hotel_bookings), 200

# @app.route('/add-review', methods=['POST'])
# @login_required
# def add_review():
#     data = request.get_json()
#     error_response, payload = authorize_request(request)
#     if error_response:
#         return error_response

#     user_id = payload.get('user_id')
#     service_type = data.get('service_type')
#     service_id = data.get('service_id')
#     rating = data.get('rating')
#     review_text = data.get('review')

#     if not all([service_type, service_id, rating, review_text]):
#         return jsonify({"message": "All fields are required"}), 400

#     conn = get_db_connection()
#     cur = conn.cursor()

#     cur.execute(
#         '''INSERT INTO reviews (user_id, service_type, service_id, rating, review)
#         VALUES (%s, %s, %s, %s, %s)''',
#         (user_id, service_type, service_id, rating, review_text)
#     )
#     conn.commit()
#     cur.close()
#     conn.close()
#     return jsonify({"message": "Review added successfully"}), 201

# @app.route('/get-reviews', methods=['GET'])
# @login_required
# def get_reviews():
#     error_response, payload = authorize_request(request)
#     if error_response:
#         return error_response

#     conn = get_db_connection()
#     cur = conn.cursor(cursor_factory=RealDictCursor)
#     cur.execute("SELECT * FROM reviews")
#     reviews = cur.fetchall()
#     cur.close()
#     conn.close()
#     return jsonify(reviews), 200

# @app.route('/admin/get-users', methods=['GET'])
# @login_required
# def get_users():
#     error_response, payload = authorize_request(request)
#     if error_response:
#         return error_response

#     if current_user.id != 1:
#         return jsonify({"message": "Unauthorized access"}), 403

#     conn = get_db_connection()
#     cur = conn.cursor(cursor_factory=RealDictCursor)
#     cur.execute("SELECT * FROM users")
#     users = cur.fetchall()
#     cur.close()
#     conn.close()
#     return jsonify(users), 200

# @app.route('/admin/get-bookings', methods=['GET'])
# @login_required
# def get_bookings():
#     error_response, payload = authorize_request(request)
#     if error_response:
#         return error_response

#     if current_user.id != 1:
#         return jsonify({"message": "Unauthorized access"}), 403

#     conn = get_db_connection()
#     cur = conn.cursor(cursor_factory=RealDictCursor)
#     cur.execute("SELECT * FROM flight_booking UNION SELECT * FROM hotel_booking")
#     bookings = cur.fetchall()
#     cur.close()
#     conn.close()
#     return jsonify(bookings), 200

# @app.route('/admin/add-admin', methods=['POST'])
# @login_required
# def add_admin():
#     error_response, payload = authorize_request(request)
#     if error_response:
#         return error_response

#     if current_user.id != 1:
#         return jsonify({"message": "Unauthorized access"}), 403

#     data = request.get_json()

#     email = data.get("email")

#     if not email:
#         return jsonify({"message": "Email is required"}), 400

#     conn = get_db_connection()
#     cur = conn.cursor(cursor_factory=RealDictCursor)

#     cur.execute("""SELECT "email" FROM "users" WHERE "email" = %s""", (email,))
#     existing_user = cur.fetchone()

#     if not existing_user:
#         cur.execute(
#             """INSERT INTO "users" ("email", "role") VALUES (%s, %s)""",
#             (email, 'admin')
#         )
#         conn.commit()
#         cur.close()
#         conn.close()
#         return jsonify({"message": "Admin added successfully"}), 201
#     else:
#         cur.close()
#         conn.close()
#         return jsonify({"message": "Email already exists"}), 400

# if __name__ == "__main__":
#     init_db()
#     app.run(debug=True)
