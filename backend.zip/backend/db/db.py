import psycopg2

def connection():
    connection = psycopg2.connect(database="users", user="postgres", password="welcome123", host="localhost", port=5432)
    cursor = connection.cursor()
    print(connection)
    print(cursor)
    return cursor, connection

